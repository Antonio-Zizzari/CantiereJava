package grafica;

/**
 * Classe di avvio dell'applicazione grafica
 * @author Iovino Davide
 * @author Sorrentino Giovanni Battista
 * @author Zizzari Antonio
 */
public class ImpresaStarter {

	public static void main(String[] args) {
		FrameImpresa f = new FrameImpresa();
		f.setVisible(true);
	}

}
